// config.js
const config = {
  // baseURL: "http://localhost:5000"
  baseURL: "https://api.futureSoulmates.com"
};

export default config;