import React from 'react'
import PartnerPreferences from '../../pages/Users/PartnerPreferences'

const PartnerTab = () => {
  return (
    <PartnerPreferences onlyPartnerPrefrence={true} />
  )
}

export default PartnerTab
