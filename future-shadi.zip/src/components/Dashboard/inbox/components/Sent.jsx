// src/components/SentTab.js
import React from 'react';

function Sent() {
  return (
    <div className="sent-tab">
      <h3>Sent Requests</h3>
      <p>Your sent connection requests will appear here</p>
      {/* Content for sent tab */}
    </div>
  );
}

export default Sent;