
import React from 'react';

const MoreMatches = () => (
  <div className="p-4">
    <h4>More Matches</h4>
    <p>Content coming soon...</p>
  </div>
);

export default MoreMatches;
