const calculateAge = (day, month, year) => {
      if (!day || !month || !year) return null;

      const birthDate = new Date(`${year}-${month}-${day}`);
      const today = new Date();

      let age = today.getFullYear() - birthDate.getFullYear();
      const m = today.getMonth() - birthDate.getMonth();

      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }

      return age;
    };

export default calculateAge